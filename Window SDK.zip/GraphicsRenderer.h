#include "window.h"

typedef void GraphicsRenderer;

GraphicsRenderer* GraphicsRenderer_create_object();
void GraphicsRenderer_ctor(GraphicsRenderer* graphicsRenderer, Window* window, COLORREF color);
void GraphicsRenderer_startRender(GraphicsRenderer* graphicsRenderer);
void GraphicsRenderer_stopRender(GraphicsRenderer* graphicsRenderer);


// Seters 
void GraphicsRenderer_setBgColor(GraphicsRenderer* graphicsRenderer, COLORREF color);