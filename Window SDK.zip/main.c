#include "window.h"
#include "GraphicsRenderer.h"
#include <stdio.h>



int wWinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPWSTR lpCmdLine, int nShowCmd) {
	Window* window = (Window*)window_create_object();
	window_ctor(window, hInstance, L"TestWindow");
	GraphicsRenderer* gr = (GraphicsRenderer*)GraphicsRenderer_create_object();
	GraphicsRenderer_ctor(gr, window, RGB(75, 75, 75));
	GraphicsRenderer_startRender(gr);
	window_start_message_handling(window);
	return 0;
}