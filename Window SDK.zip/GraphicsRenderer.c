/*
	GraphicsRenderer Internal
	By Mantissa 15.04.2023
*/
#include "window.h"

typedef struct _GraphicsRenderer{
	Window* window;
	HANDLE drawThread;
	//GraphicObjectList objList;
	COLORREF bgColor;
	BOOL isDrawing;
} GraphicsRenderer;

void __GraphicsRenderer_drawFrame(GraphicsRenderer* graphicsRenderer);

GraphicsRenderer *GraphicsRenderer_create_object() {
	return((GraphicsRenderer*)malloc(sizeof(GraphicsRenderer)));
}

void GraphicsRenderer_ctor(GraphicsRenderer* graphicsRenderer, Window* window, COLORREF color) {
	graphicsRenderer->window = window;
	graphicsRenderer->isDrawing = FALSE;
	graphicsRenderer->bgColor = color;
	HANDLE thread = CreateThread(NULL, 0, (LPTHREAD_START_ROUTINE)__GraphicsRenderer_drawFrame, graphicsRenderer, 0, 0);
	if (thread == NULL)
		ExitProcess(1);
	graphicsRenderer->drawThread = thread;
}

void __GraphicsRenderer_drawFrame(GraphicsRenderer *graphicsRenderer) {
	HDC hdc = GetDC(window_getHWND(graphicsRenderer->window));
	HDC backDC = CreateCompatibleDC(hdc);
	while (graphicsRenderer->isDrawing) {
		RECT* clientRect = window_getClientRect(graphicsRenderer->window);
		HBITMAP backBM = CreateCompatibleBitmap(hdc, clientRect->right, clientRect->bottom);
		DeleteObject(SelectObject(backDC, backBM));
		HBRUSH bgBrush = CreateSolidBrush(graphicsRenderer->bgColor);
		DeleteObject(SelectObject(backDC, bgBrush));
		FillRect(backDC, window_getClientRect(graphicsRenderer->window), bgBrush);
		DeleteObject(bgBrush);
		window_setBackDC(graphicsRenderer->window, backDC);
		HBRUSH brush = CreateSolidBrush(RGB(141, 162, 183));
		HPEN pen = CreatePen(PS_SOLID, 0, RGB(141, 162, 183));
		HBRUSH oldBrush = SelectObject(backDC, brush);
		HPEN oldPen = SelectObject(backDC, pen);
		Rectangle(backDC, 102, 148, 186 + 102, 472 + 148);
		Rectangle(backDC, 320, 148, 186 + 320, 472 + 148);
		DeleteObject(SelectObject(backDC, oldBrush));
		DeleteObject(SelectObject(backDC, oldPen));
		brush = CreateSolidBrush(RGB(211, 220, 229));
		pen = CreatePen(PS_SOLID, 0, RGB(211, 220, 229));
		oldBrush = SelectObject(backDC, brush);
		oldPen = SelectObject(backDC, pen);
		Rectangle(backDC, 538, 148, 384 + 538, 243 + 148);
		DeleteObject(SelectObject(backDC, oldBrush));
		DeleteObject(SelectObject(backDC, oldPen));
		brush = CreateSolidBrush(RGB(83, 119, 145));
		pen = CreatePen(PS_SOLID, 0, RGB(83, 119, 145));
		oldBrush = SelectObject(backDC, brush);
		oldPen = SelectObject(backDC, pen);
		Rectangle(backDC, 538, 436, 176 + 538, 184 + 436);
		Rectangle(backDC, 746, 436, 176 + 746, 184 + 436);
		DeleteObject(SelectObject(backDC, oldBrush));
		DeleteObject(SelectObject(backDC, oldPen));
		brush = CreateSolidBrush(RGB(211, 224, 233));
		pen = CreatePen(PS_SOLID, 0, RGB(211, 224, 233));
		oldBrush = SelectObject(backDC, brush);
		oldPen = SelectObject(backDC, pen);
		Rectangle(backDC, 0, 0, 1024, 60);
		Rectangle(backDC, 0, 708, 1024, 60 + 708);
		//CleanUp
		DeleteObject(SelectObject(backDC, oldBrush));
		DeleteObject(SelectObject(backDC, oldPen));
		RedrawWindow(window_getHWND(graphicsRenderer->window), 0, 0, RDW_INVALIDATE);
		DeleteObject(backBM);
		Sleep(16);
	}
	DeleteDC(backDC);
	ReleaseDC(window_getHWND(graphicsRenderer->window), hdc);
}

void GraphicsRenderer_startRender(GraphicsRenderer *graphicsRenderer) {
	graphicsRenderer->isDrawing = TRUE;
}

void GraphicsRenderer_stopRender(GraphicsRenderer *graphicsRenderer) {
	graphicsRenderer->isDrawing = FALSE;
}

BOOL GraphicsRenderer_addGraphicObject(GraphicsRenderer *graphicsRenderer) {

}

BOOL GraphicsRenderer_delGraphicObject(GraphicsRenderer *graphicsRenderer) {

}

void GraphicsRenderer_setBgColor(GraphicsRenderer *graphicsRenderer, COLORREF color) {
	graphicsRenderer->bgColor = color;
}