/*
	Window Internal
	By Mantissa 15.04.2023
*/
#include <Windows.h>
typedef struct _Window {
	ATOM aWnd;
	HWND hWnd;
	HINSTANCE hInstance;
	PWSTR windowName;
	UINT w;
	UINT h;
	HDC backHdc;
	//ControlsList controlList;
	WNDPROC wndProc;
	RECT *clientRect;
	BOOL isVisible;
} Window;

// Internal functions
LRESULT WndProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam);
BOOL __window_register(Window* window);
BOOL __window_create(Window* window);

// Return the Window object
Window* window_create_object() {
	return (Window*)malloc(sizeof(Window));
}

/*
* Constructor fow window object, create window
*/
void window_ctor(Window* window, HINSTANCE hInstance, PWSTR windowName, int w, int h) {
	window->hInstance = hInstance;
	window->windowName = windowName;
	window->wndProc = WndProc;
	window->w = w;
	window->h = h;
	__window_create(window);
	window->clientRect = (RECT*)malloc(sizeof(RECT));
	GetClientRect(window->hWnd, window->clientRect);
}

// Destructor for Window object
void window_dtor(Window* window) {

}

BOOL __window_register(Window* window) {
	WNDCLASSEX wndClass = { 0 };
	wndClass.cbSize = sizeof(WNDCLASSEX);
	wndClass.lpszClassName = window->windowName;
	wndClass.hInstance = window->hInstance;
	wndClass.lpfnWndProc = window->wndProc;
	wndClass.hbrBackground = GetStockObject(WHITE_BRUSH);
	ATOM atom = RegisterClassEx(&wndClass);
	if (atom == INVALID_ATOM) {
		MessageBox(0, L"Error while register window class.", L"Fatal error", MB_OK);
		return FALSE;
	}
	window->aWnd = atom;
	return TRUE;
}

// Call the CreateWindowEx function
BOOL __window_create(Window* window) {
	if (!__window_register(window)) {
		return FALSE;
	}
	HWND hWnd = CreateWindowEx(0, window->windowName, window->windowName, WS_OVERLAPPEDWINDOW | WS_VISIBLE, CW_USEDEFAULT, CW_USEDEFAULT,
	800, 600, 0, 0, window->hInstance, window);
	if (hWnd == NULL) {
		MessageBox(0, L"Error while create window.", L"Fatal error", MB_OK);
		return FALSE;
	}
	return TRUE;
}

LRESULT WndProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam) {
	Window* window = (Window*)GetWindowLongPtr(hWnd, GWLP_USERDATA);
	switch (msg) {
		case WM_CREATE:
			CREATESTRUCT* pCreate = (CREATESTRUCT*)lParam;
			window = pCreate->lpCreateParams;
			window->hWnd = hWnd;
			SetWindowLongPtr(window->hWnd, GWLP_USERDATA, window);
			return 0;
		case WM_DESTROY:
			ExitProcess(0);
			return 0;
		case WM_PAINT:
			PAINTSTRUCT ps = { 0 };
			HDC hdc = BeginPaint(hWnd, &ps);
			BitBlt(hdc, 0, 0, window->clientRect->right, window->clientRect->bottom, window->backHdc, 0, 0, SRCCOPY);
			EndPaint(hWnd, &ps);
			return 0;
		case WM_SIZE:
			GetClientRect(window->hWnd, window->clientRect);
			return 0;
		default:
			return(DefWindowProcW(hWnd, msg, wParam, lParam));
	}
}

void window_start_message_handling(Window *window) {
	MSG msg = { 0 };
	while (GetMessage(&msg, window->hWnd, 0, 0)) {
		TranslateMessage(&msg);
		DispatchMessageW(&msg);
	}
}

// Geters, Seters
HDC window_getDC(Window* window) {
	return window->backHdc;
}

HWND window_getHWND(Window* window) {
	return window->hWnd;
}

RECT *window_getClientRect(Window* window) {
	return window->clientRect;
}

void window_setBackDC(Window* window, HDC hdc) {
	window->backHdc = hdc;
}