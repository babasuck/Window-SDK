/*
	Window External
	By Mantissa 15.04.2023
*/
#include <Windows.h>
typedef void Window;

Window* window_create_object();
void window_ctor(Window* window, HINSTANCE hInstance, PWSTR windowName);
void window_dtor(Window* window);
void window_start_message_handling(Window* window);

// Geters
HDC window_getDC(Window* window);
HWND window_getHWND(Window* window);
RECT* window_getClientRect(Window* window);

// Seters 
void window_setBackDC(Window* window, HDC hdc);